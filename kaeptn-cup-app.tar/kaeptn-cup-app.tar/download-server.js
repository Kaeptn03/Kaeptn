const express = require('express');
const path = require('path');
const app = express();

app.get('/download', (req, res) => {
  const file = path.join(__dirname, 'kaeptn-cup-app.tar.gz');
  res.download(file, 'kaeptn-cup-app.tar.gz', (err) => {
    if (err) {
      console.error('Download error:', err);
      res.status(500).send('Error downloading file');
    }
  });
});

app.get('/', (req, res) => {
  res.send(`
    <html>
      <head>
        <title>Kaeptn Cup - Download</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: #0A0E27;
            color: white;
            margin: 0;
          }
          .container {
            text-align: center;
          }
          h1 {
            color: #FF6B00;
          }
          a {
            display: inline-block;
            padding: 15px 30px;
            background: #FF6B00;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 18px;
            margin-top: 20px;
          }
          a:hover {
            background: #ff8533;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>Kaeptn Cup App</h1>
          <p>Klicke auf den Button, um den Code herunterzuladen</p>
          <a href="/download">📥 Code herunterladen (262 KB)</a>
        </div>
      </body>
    </html>
  `);
});

const PORT = 5000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Download-Server läuft auf Port ${PORT}`);
});
