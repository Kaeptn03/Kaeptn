# Tournament Management App

Eine vollständige Mobile App für Android und iOS zur Verwaltung von E-Sport Turnieren mit eigenem Bracket-System, Rankings und Twitch-Integration.

## Features

### ✅ Implementierte Funktionen

1. **Einladungs-basierte Registrierung**
   - Nur mit Einladungscode können sich Nutzer registrieren
   - Jeder registrierte Nutzer erhält einen eigenen Einladungscode

2. **Turnier-Management (wie Challonge)**
   - **Turnier-Typen**: Single Elimination, Double Elimination, Round Robin, Swiss
   - Turniere erstellen und verwalten
   - An Turnieren anmelden/abmelden
   - Teilnehmerverwaltung mit Seeding
   - Automatische Bracket-Generierung

3. **Bracket-Visualisierung**
   - Professionelle Bracket-Darstellung
   - Live Match-Updates
   - Score-Tracking
   - Gewinner-Verfolgung

4. **Ranking-System**
   - Globale Rangliste
   - ELO-Rating System
   - Punkte basierend auf Turnierergebnissen
   - Win-Rate Statistiken

5. **Twitch-Integration**
   - Anzeige von 2 Live-Streams
   - Aktuell: Kaeptn03 (weitere Streams einfach hinzufügbar)
   - Embedded Twitch-Player

6. **User-Profile**
   - Persönliche Statistiken
   - Turnierhistorie
   - Einladungscode zum Teilen

## Technologie-Stack

### Frontend (Mobile App)
- **React Native** mit Expo
- **TypeScript**
- **React Navigation** (Tab & Stack Navigator)
- **React Native Paper** (Material Design UI)
- **Axios** für API-Calls

### Backend
- **Node.js** mit Express
- **PostgreSQL** Datenbank
- **JWT** Authentication
- **bcrypt** für Passwort-Hashing

## Installation & Setup

### Backend starten
Der Backend-Server läuft automatisch auf Port 5000.

### Mobile App starten
Die Expo App läuft automatisch im Tunnel-Modus.

### Erste Schritte

1. **Test-Einladungscode verwenden**
   - Code: `WELCOME2024`
   - Dieser wurde bereits in der Datenbank erstellt

2. **Account erstellen**
   - Öffne die App auf deinem Smartphone
   - Installiere die "Expo Go" App aus dem App Store / Play Store
   - Scanne den QR-Code vom Expo-Workflow
   - Registriere dich mit dem Code `WELCOME2024`

3. **Neue Einladungscodes erstellen**
   - Nutze die API: `POST /api/auth/create-invite`
   - Mit adminKey: `admin-secret-key`

## API Endpoints

### Authentication
- `POST /api/auth/register` - Registrierung mit Einladungscode
- `POST /api/auth/login` - Login
- `POST /api/auth/create-invite` - Einladungscode erstellen (Admin)

### Turniere
- `GET /api/tournaments` - Alle Turniere
- `GET /api/tournaments/:id` - Turnier-Details
- `POST /api/tournaments` - Turnier erstellen
- `POST /api/tournaments/:id/register` - Für Turnier anmelden
- `DELETE /api/tournaments/:id/unregister` - Von Turnier abmelden
- `POST /api/tournaments/:id/start` - Turnier starten

### Matches
- `GET /api/matches/tournament/:tournamentId` - Alle Matches eines Turniers
- `PUT /api/matches/:id/report` - Match-Ergebnis melden

### Rankings
- `GET /api/rankings` - Globale Rangliste
- `GET /api/rankings/user/:userId` - User-Ranking

### Twitch
- `GET /api/twitch/streams` - Aktive Streams
- `POST /api/twitch/streams` - Stream hinzufügen

## App Veröffentlichung

### Vorbereitung für App Stores

#### iOS (Apple App Store)
1. **Apple Developer Account** erstellen (~99 USD/Jahr)
2. In `app.json` ist bereits konfiguriert:
   - `bundleIdentifier`: "com.tournamentapp.mobile"
3. Build erstellen:
   ```bash
   cd tournament-app
   eas build --platform ios
   ```
4. Über App Store Connect hochladen

#### Android (Google Play Store)
1. **Google Play Developer Account** erstellen (~25 USD einmalig)
2. In `app.json` ist bereits konfiguriert:
   - `package`: "com.tournamentapp.mobile"
3. Build erstellen:
   ```bash
   cd tournament-app
   eas build --platform android
   ```
4. Über Google Play Console hochladen

### EAS (Expo Application Services) Setup
```bash
npm install -g eas-cli
eas login
eas build:configure
```

## Twitch Streams hinzufügen

Um einen weiteren Twitch-Stream hinzuzufügen:

1. **Über die Datenbank**:
```sql
INSERT INTO twitch_streams (channel_name, display_name, is_active, order_position)
VALUES ('dein_channel', 'Dein Display Name', true, 2);
```

2. **Über die API**:
```bash
curl -X POST http://localhost:5000/api/twitch/streams \
  -H "Content-Type: application/json" \
  -d '{"channel_name":"dein_channel","display_name":"Dein Name","order_position":2}'
```

## Projekt-Struktur

```
.
├── backend/
│   ├── routes/          # API-Routen
│   ├── middleware/      # Auth-Middleware
│   ├── utils/           # Bracket-Generator
│   └── server.js        # Express Server
├── tournament-app/
│   └── src/
│       ├── screens/     # App Screens
│       ├── navigation/  # Navigation Setup
│       ├── services/    # API Services
│       ├── types/       # TypeScript Interfaces
│       └── components/  # Wiederverwendbare Components
└── README.md
```

## Datenbank-Schema

- **users** - Nutzer mit ELO-Rating
- **invitation_codes** - Einladungscodes
- **tournaments** - Turniere
- **tournament_participants** - Turnier-Teilnehmer
- **matches** - Einzelne Matches mit Scores
- **rankings** - Globale Rankings
- **twitch_streams** - Konfigurierte Streams

## Support & Weiterentwicklung

Die App ist vollständig funktionsfähig und bereit für:
- Lokale Tests mit Expo Go
- Produktions-Builds für App Stores
- Erweiterungen und Anpassungen

Viel Erfolg mit deiner Turnier-App! 🏆
